# Databricks notebook source
# Get data
df = spark.table("workspace.ecommerce_project.ecommerce_data")
display(df)

# COMMAND ----------

# Print Shcema

df.printSchema()
df.count

# COMMAND ----------

# NULL values check 
from pyspark.sql.functions import col

df.select([
    (col(c).isNull().cast("int").alias(c))
    for c in df.columns
]).groupBy().sum().display()