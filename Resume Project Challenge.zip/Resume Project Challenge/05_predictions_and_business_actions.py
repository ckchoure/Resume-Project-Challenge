# Databricks notebook source
# MAGIC %md
# MAGIC # Load Product_gold data

# COMMAND ----------

# Load Gold layer data
df_gold = spark.table("workspace.ecommerce_project.product_gold")
display(df_gold)

# COMMAND ----------

# MAGIC %md
# MAGIC # Load Model

# COMMAND ----------

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.ml import Pipeline

assembler = VectorAssembler(
    inputCols=["total_quantity_sold", "avg_rating", "total_orders"],
    outputCol="features"
)

lr = LinearRegression(
    featuresCol="features",
    labelCol="total_revenue"
)

pipeline = Pipeline(stages=[assembler, lr])

model = pipeline.fit(df_gold)

# COMMAND ----------

predictions = model.transform(df_gold)
display(predictions)

# COMMAND ----------

# MAGIC %md
# MAGIC # Add recommended business action

# COMMAND ----------

# Add recommended business action
from pyspark.sql.functions import when, col

final_output = predictions.withColumn(
    "recommended_action",
    when(col("product_performance") == "High", "Increase inventory and marketing")
    .when(col("product_performance") == "Medium", "Maintain stock and monitor")
    .otherwise("Apply discount or reconsider product")
)


# COMMAND ----------

final_table = final_output.select(
    "Product",
    "Category",
    "total_quantity_sold",
    "total_orders",
    "total_revenue",
    col("prediction").alias("predicted_revenue"),
    "avg_rating",
    "product_performance",
    "recommended_action"
).withColumn("predicted_revenue", col("predicted_revenue").cast("decimal(20,2)"))

display(final_table)

# COMMAND ----------

# MAGIC %md
# MAGIC # Save Final Table

# COMMAND ----------

final_table.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("workspace.ecommerce_project.final_business_output")