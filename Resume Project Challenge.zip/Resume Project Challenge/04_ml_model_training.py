# Databricks notebook source
# MAGIC %md
# MAGIC # Load Gold layer

# COMMAND ----------

# Load Gold layer data

df = spark.table("workspace.ecommerce_project.product_gold")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Required ML imports

# COMMAND ----------


from pyspark.ml.feature import StringIndexer, VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.ml import Pipeline


# COMMAND ----------

# MAGIC %md
# MAGIC # Convert numeric columns into a single feature vector
# MAGIC

# COMMAND ----------



assembler = VectorAssembler(
    inputCols=["total_quantity_sold", "avg_rating", "total_orders"],
    outputCol="features"
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Train-Test Split

# COMMAND ----------

# Split data into training and testing sets

train_df, test_df = df.randomSplit([0.8, 0.2], seed=42)


# COMMAND ----------

# MAGIC %md
# MAGIC # Model Define

# COMMAND ----------

# Linear Regression model
# Chosen because it is simple, fast, and explainable

lr = LinearRegression(
    featuresCol="features",
    labelCol="total_revenue"
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Create ML Pipeline

# COMMAND ----------

# Pipeline ensures reproducibility and clean workflow

pipeline = Pipeline(stages=[assembler, lr])

# COMMAND ----------

# MAGIC %md
# MAGIC # Train Model

# COMMAND ----------

# Train the model on training data

model = pipeline.fit(train_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Test Data

# COMMAND ----------

# Generate predictions on test data

predictions = model.transform(test_df)
display(predictions)

# COMMAND ----------

# Evaluate model performance

from pyspark.ml.evaluation import RegressionEvaluator

evaluator = RegressionEvaluator(
    labelCol="total_revenue",
    predictionCol="prediction",
    metricName="rmse"
)

rmse = evaluator.evaluate(predictions)
print(f"RMSE: {rmse}")

# COMMAND ----------

# MAGIC %md
# MAGIC # MLflow Tracking

# COMMAND ----------

import os

# Tell MLflow where to store temporary Spark ML artifacts
os.environ["MLFLOW_DFS_TMP"] = "/Volumes/workspace/ecommerce_project/ecommerce"

# COMMAND ----------

from mlflow.models.signature import ModelSignature
from mlflow.types.schema import Schema, ColSpec

# Define input schema using original numeric columns (NOT vector)
input_schema = Schema([
    ColSpec("long", "total_quantity_sold"),
    ColSpec("double", "avg_rating"),
    ColSpec("long", "total_orders")
])

# Define output schema
output_schema = Schema([
    ColSpec("double", "prediction")
])

# Create model signature
signature = ModelSignature(inputs=input_schema, outputs=output_schema)


# COMMAND ----------

import mlflow
import mlflow.spark

with mlflow.start_run():

    # Log parameters
    mlflow.log_param("model_type", "Linear Regression")
    mlflow.log_param(
        "features",
        "total_quantity_sold, avg_rating, total_orders"
    )

    # Log metric
    mlflow.log_metric("rmse", rmse)

    # Log Spark ML pipeline model with clean signature
    mlflow.spark.log_model(
        spark_model=model,
        artifact_path="sales_prediction_model",
        signature=signature,
        pip_requirements=["pyspark"]
    )
