# Databricks notebook source
# Load cleaned data from Silver layer

df = spark.table("workspace.ecommerce_project.Ecommerce_data_silver")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Required Functions Import

# COMMAND ----------

# Import aggregation and utility functions for feature engineering

from pyspark.sql.functions import (
    sum,
    avg,
    count,
    year,
    month,
    when,
    col
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Product-Level Feature

# COMMAND ----------

# Aggregate data at product and category level
# This helps in understanding product performance

product_features = (
    df.groupBy("Product", "Category")
      .agg(
          sum("Quantity").alias("total_quantity_sold"),
          sum("TotalAmount").alias("total_revenue"),
          avg("Rating").alias("avg_rating"),
          count("OrderID").alias("total_orders")
      )
      .withColumn("total_revenue", col("total_revenue").cast("decimal(20,2)"))
      .withColumn("avg_rating", col("avg_rating").cast("decimal(5,2)"))
      .orderBy(col("total_revenue").desc())
)

display(product_features)

# COMMAND ----------

# MAGIC %md
# MAGIC # Monthly Sales Trend

# COMMAND ----------

# Create year and month columns from OrderDate
# This helps analyze sales trend over time

monthly_sales = (
    df.withColumn("year", year("OrderDate"))
      .withColumn("month", month("OrderDate"))
      .groupBy("year", "month")
      .agg(
          sum("TotalAmount").alias("monthly_revenue"),
          sum("Quantity").alias("monthly_quantity")
      )
      .withColumn("monthly_revenue", col("monthly_revenue").cast("decimal(20,2)"))
      .orderBy(col("year"), col("month"))
)

display(monthly_sales)

# COMMAND ----------

# MAGIC %md
# MAGIC # Business Performance Tag (High / Medium / Low)

# COMMAND ----------

# Classify products based on revenue contribution
# This converts raw numbers into actionable insights

product_gold = product_features.withColumn(
    "product_performance",
    when(col("total_revenue") > 31000000, "High")
    .when(col("total_revenue") > 29000000, "Medium")
    .otherwise("Low")
)

display(product_gold)


# COMMAND ----------

# MAGIC %md
# MAGIC # Save Tables

# COMMAND ----------

# Save product-level features as Gold table
# This table will be used for ML training and business reporting

product_gold.write \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("workspace.ecommerce_project.product_gold")

# COMMAND ----------

# Save monthly sales trend table
# Useful for dashboards and time-series analysis

monthly_sales.write \
    .option("mergeSchema", "true") \
    .format("delta") \
    .mode("overwrite") \
    .saveAsTable("workspace.ecommerce_project.monthly_sales_gold")