# Databricks notebook source
# MAGIC %md
# MAGIC # Load Data

# COMMAND ----------

# Get data
df = spark.table("workspace.ecommerce_project.ecommerce_data")
df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC # Remove null OrderID

# COMMAND ----------

from pyspark.sql.functions import col
df_clean = df.filter(col("OrderID").isNotNull())

# COMMAND ----------

# MAGIC %md
# MAGIC # Remove Duplicate 

# COMMAND ----------


df_clean = df.dropDuplicates(['OrderID'])


# COMMAND ----------

# MAGIC %md
# MAGIC # Convert Order Date to proper date

# COMMAND ----------

from pyspark.sql.functions import to_date, col

df_clean = df_clean.withColumn(
    "OrderDate",
    to_date(col("OrderDate"), "yyyy-MM-dd")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Cast numeric columns

# COMMAND ----------

from pyspark.sql.types import DoubleType, IntegerType

df_clean = (
    df_clean
    .withColumn("Price", col("Price").cast(DoubleType()))
    .withColumn("Quantity", col("Quantity").cast(IntegerType()))
    .withColumn("TotalAmount", col("TotalAmount").cast(DoubleType()))
    .withColumn("Rating", col("Rating").cast(DoubleType()))
)


# COMMAND ----------

# MAGIC %md
# MAGIC # Check Range

# COMMAND ----------

# check range
from pyspark.sql.functions import col



df_clean.filter((col("Price") >=0 ))
df_clean.filter((col("Rating") >=0 ))
df_clean.filter((col("Reviews") >=0 ))
df_clean.filter((col("Quantity") >=0))
df_clean.filter((col("TotalAmount") >=0))


# COMMAND ----------

# MAGIC %md
# MAGIC # Data Quality Check

# COMMAND ----------

print("Before Cleaning:", df.count())
print("After Cleaning:", df_clean.count())

# COMMAND ----------

df_clean.printSchema()
display(df_clean)

# COMMAND ----------

# MAGIC %md
# MAGIC # Create Delta Table

# COMMAND ----------

df_clean.write \
  .format("delta") \
  .mode("overwrite") \
  .saveAsTable("workspace.ecommerce_project.Ecommerce_data_silver")